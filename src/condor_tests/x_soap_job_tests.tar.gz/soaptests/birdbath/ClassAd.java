package birdbath;

import condor.ClassAdStructAttr;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class ClassAd
{
	//private Map<String, String> map;
	private Map map;

	public ClassAd()
	{
		//map = new HashMap<String, String>();
		map = new HashMap();
	}

	public ClassAd(ClassAdStructAttr[] classAd)
	{
		this();

//		for (ClassAdStructAttr attribute : classAd)
//		{
//			map.put(attribute.getName(), attribute.getValue());
//		}
		for (int i = 0; i < classAd.length; i++) {
         ClassAdStructAttr attribute = classAd[i];

			map.put(attribute.getName(), attribute.getValue());
		}
	}

	public String get(String name)
	{
		//return map.get(name);
		return (String) map.get(name);
	}

	public String toString()
	{
		String output = "[\n";

//		for (String name : map.keySet())
//		{
//			output += "\t" + name + "=" + map.get(name) + ";\n";
//		}
      Iterator keys = map.keySet().iterator();
      while (keys.hasNext()) {
         String name = (String) keys.next();
			output += "\t" + name + "=" + map.get(name) + ";\n";
		}

		output += "]";

		return output;
	}
}
