import birdbath.*;
import condor.*;
import java.rmi.*;

import birdbath.Transaction;

public class SubmitExpireTest1
extends AbstractScheddTestCase
{
   // This test just takes down the Schedd via a double free around DataPtr
    protected void runTest()
    throws Throwable
    {
        Transaction transaction1 = schedd.createTransaction();
        transaction1.begin(1);
    }

    private static void check(Status status, String message)
    {
        assertTrue(message, status.getCode().equals(StatusCode.SUCCESS));
    }
}

