import java.io.FileOutputStream;

public class ScheddSendASCIISpoolFileTestCase
	extends AbstractScheddSpoolFileTestCase
{
	protected void generate(FileOutputStream testFileOutput)
		throws Exception
	{
		for (int i = 0; i < 333 * 1024; i++)
		{
			testFileOutput.write('a' + (int) (Math.random() * ('z' - 'a')));
		}
	}
}
