import java.io.FileOutputStream;

public class ScheddSendEmptySpoolFileTestCase
	extends AbstractScheddSpoolFileTestCase
{
	protected void generate(FileOutputStream testFileOutput)
		throws Exception
	{
	}
}
