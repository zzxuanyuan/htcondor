/**
 * CondorCollectorPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package condor;

public interface CondorCollectorPortType extends java.rmi.Remote {

    /**
     * Service definition of function condor__getVersionString
     */
    public condor.StringAndStatus getVersionString() throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__getPlatformString
     */
    public condor.StringAndStatus getPlatformString() throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__insertAd
     */
    public condor.Status insertAd(condor.ClassAdType type, condor.ClassAdStructAttr[] ad) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__queryStartdAds
     */
    public condor.ClassAdStructAttr[][] queryStartdAds(java.lang.String constraint) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__queryScheddAds
     */
    public condor.ClassAdStructAttr[][] queryScheddAds(java.lang.String constraint) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__queryMasterAds
     */
    public condor.ClassAdStructAttr[][] queryMasterAds(java.lang.String constraint) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__querySubmittorAds
     */
    public condor.ClassAdStructAttr[][] querySubmittorAds(java.lang.String constraint) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__queryLicenseAds
     */
    public condor.ClassAdStructAttr[][] queryLicenseAds(java.lang.String constraint) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__queryStorageAds
     */
    public condor.ClassAdStructAttr[][] queryStorageAds(java.lang.String constraint) throws java.rmi.RemoteException;

    /**
     * Service definition of function condor__queryAnyAds
     */
    public condor.ClassAdStructAttr[][] queryAnyAds(java.lang.String constraint) throws java.rmi.RemoteException;
}
